import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { HttpClient} from '@angular/common/http';
import { Employee} from '../Employee';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  empList:any=[];
  
  constructor(private employeeService:EmployeeService) { 
  this.empList= this.employeeService.empList;
  }
  
  ngOnInit() {
    this.empList= this.employeeService.empList;
    
  }
  reload(){
    this.empList= this.employeeService.empList;
  }

  flag=false;
id;name;email;phone;

em:Employee=new Employee;
  changeFlag(e:Employee){
    this.flag=true;
    this.id=e.id;this.name=e.name;this.email=e.email;this.phone=e.phone;
    

  }
  update(f){
   let b:Employee=new Employee;
  b=f;
  console.log(b);
  this.employeeService.updateEmpDetails(b);
  }

  delete(code:number){
    this.employeeService.deleteEmp(code);
    this.empList= this.employeeService.empList;
  }
  
}
