import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  empList: any = [];
  em: Employee = new Employee();
 
  constructor(private employeeService: EmployeeService) {
    this.employeeService.getEmpDetails().subscribe(data => this.empList = data);
  }

  ngOnInit() {
  }

  

  insert(data) {
    alert(`Id: ${data.id}  Employee Name: ${data.name} Email: ${data.email} Phone: ${data.phone}`);
    this.em.id = data.id;
    this.em.name = data.name;
    this.em.email = data.email;
    this.em.phone = data.phone;
    console.log(this.em);
    this.employeeService.setEmpDetails(this.em);
  }
  show(data): void {
    alert(`Employee Added in the list\nId: ${data.id} Name: ${data.name} Author: ${data.email} Genre: ${data.phone}`);
  }
  
}
