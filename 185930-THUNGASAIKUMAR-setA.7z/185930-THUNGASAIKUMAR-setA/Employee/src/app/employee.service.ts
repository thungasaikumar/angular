import { Injectable } from '@angular/core';
import { Employee } from './Employee';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  

constructor(private httpClient: HttpClient) {

  this.getEmpDetails().subscribe(data => this.empList = data);
}

empList: Array<Employee> = [];

url: string = "/assets/employee.json";


getEmpDetails(): any {
  return this.httpClient.get<Employee>(this.url);
}


deleteEmp(id: number): void {
  let i = 0;
  for (let emp of this.empList) {
    if (emp.id == id) {
      console.log("employee id " + emp.id);
      console.log(this.empList.splice(i, 1));
    }
    i++;
  }

}

setEmpDetails(emp: Employee) {
  this.empList.push(emp);

}




updateEmpDetails(emp: Employee) {
  for (let e of this.empList) {
    if (emp.id == e.id) {
      e.id = emp.id;
      e.name = emp.name;
      e.email = emp.email;
      e.phone = emp.phone;
    }
  }
  console.log(this.empList);
}
}